export interface Employee {
    name: String,
    salary: Number,
    age : Number
    }